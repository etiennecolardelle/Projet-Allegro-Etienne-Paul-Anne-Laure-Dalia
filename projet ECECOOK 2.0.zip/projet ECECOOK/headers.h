//
// Created by bllcp on 06/04/2024.
//

#ifndef PROJET_ECECOOK_HEADERS_H
#define PROJET_ECECOOK_HEADERS_H

#include <allegro.h>
#include <stdio.h>

#define LARGEUR_ECRAN 800
#define HAUTEUR_ECRAN 600

BITMAP *page;
BITMAP *jeu;
BITMAP *joueur;
BITMAP *cuisinier;
BITMAP *pseudo;
BITMAP *regle;
BITMAP *niveau[5];
BITMAP *objet;
BITMAP *Objet2;
BITMAP *POUBELLE;
BITMAP *steakcuit;
BITMAP *PLAQUE;
BITMAP *image_menu[10];


typedef struct {
    char pseudo[50];
    int pos_x, pos_y;
    int dx, dy;
    int frame_counter;
    int rayon;
    int couleur;
}Personnage;

Personnage joueur1;
Personnage joueur2;

typedef struct {
    int pos_x, pos_y;
    int dx, dy;
    int tenu; // 1 si tenu par un joueur sinon 0
    int cooking_timer;
    int cooked;
}Objet;

typedef struct {
    int pos_x;
    int pos_y;
} Poubelle;
Poubelle poubelle;

typedef struct {
    int pos_x;
    int pos_y;
} Plaque;
Plaque plaque;

Objet objet1;
Objet objet2;

int map[12][20];

void menu();
int jouer();
void commandes();
int quitter();
int Pseudo();
int RegleDuJeu();
int chargementniveau();
int Niveau1();
int Niveau2();
int Niveau3();
void init_map();
int initialisation();
void gestion_mouv();

#endif //PROJET_ECECOOK_HEADERS_H
