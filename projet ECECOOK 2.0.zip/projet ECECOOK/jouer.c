#include "headers.h"

int jouer() {
    clear_bitmap(screen);
    // Load images
    jeu = load_bitmap("image/jeu/image_jeu.bmp", NULL);
    joueur = load_bitmap("image/jeu/joueur.bmp", NULL);
    objet = load_bitmap("image/jeu/steak.bmp", NULL);
    Objet2 = load_bitmap("image/jeu/salade.bmp", NULL);
    steakcuit = load_bitmap("image/jeu/steakcuit.bmp", NULL);
    POUBELLE = load_bitmap("image/jeu/poubelle.bmp", NULL);
    PLAQUE = load_bitmap("image/jeu/plaque.bmp", NULL);
    cuisinier = load_bitmap("image/jeu/cuisinier2.bmp", NULL);

    if (!jeu || !joueur || !objet) {
        allegro_message("Erreur lors du chargement de l'image !");
        return 1;
    }

    initialisation();

    while (!key[KEY_CAPSLOCK]) {
        clear_bitmap(page);
        blit(jeu, page, 0, 0, 0, 0, jeu->w, jeu->h);

        gestion_mouv();

        // Gestion de la prise/lâcher de l'objet par les joueurs (touche C)
        if (key[KEY_C]) {
            if (!objet1.tenu) { // Si l'objet n'est pas tenu
                // Vérifier si un joueur est proche de l'objet
                if ((abs(joueur1.pos_x - objet1.pos_x - joueur1.rayon) < 20 && abs(joueur1.pos_y - objet1.pos_y- joueur1.rayon) < 20))  {
                    objet1.tenu = 1; // L'objet est maintenant tenu
                }
            } else { // Si l'objet est tenu
                objet1.tenu = 0; // L'objet est maintenant lâché
                objet1.pos_x = joueur1.pos_x;
                objet1.pos_y = joueur1.pos_y;
            }
        }

        // Gestion de la prise/lâcher de l'objet par le joueur 2 (touche L)
        if (key[KEY_L]) {
            if (!objet1.tenu) { // Si l'objet n'est pas tenu
                // Vérifier si le joueur 2 est proche de l'objet
                if (abs(joueur2.pos_x - objet1.pos_x- joueur2.rayon) < 20 && abs(joueur2.pos_y - objet1.pos_y- joueur2.rayon) < 20) {
                    objet1.tenu = 1; // L'objet est maintenant tenu
                }
            } else { // Si l'objet est tenu
                objet1.tenu = 0; // L'objet est maintenant lâché
                objet1.pos_x = joueur2.pos_x;
                objet1.pos_y = joueur2.pos_y;
            }
        }

        if (key[KEY_C]) {
            if (!objet2.tenu) { // Si l'objet n'est pas tenu
                // Vérifier si le joueur 1 est proche de l'objet 2
                if (abs(joueur1.pos_x - objet2.pos_x- joueur1.rayon) < 20 && abs(joueur1.pos_y - objet2.pos_y- joueur1.rayon) < 20) {
                    objet2.tenu = 1; // L'objet est maintenant tenu
                }
            } else { // Si l'objet est tenu
                objet2.tenu = 0; // L'objet est maintenant lâché
                objet2.pos_x = joueur1.pos_x;
                objet2.pos_y = joueur1.pos_y;
            }
        }

        if (key[KEY_L]) {
            if (!objet2.tenu) { // Si l'objet n'est pas tenu
                // Vérifier si le joueur 2 est proche de l'objet 2
                if (abs(joueur2.pos_x - objet2.pos_x- joueur2.rayon) < 20 && abs(joueur2.pos_y - objet2.pos_y- joueur2.rayon) < 20) {
                    objet2.tenu = 1; // L'objet est maintenant tenu
                }
            } else { // Si l'objet est tenu
                objet2.tenu = 0; // L'objet est maintenant lâché
                objet2.pos_x = joueur2.pos_x;
                objet2.pos_y = joueur2.pos_y;
            }
        }

        if (objet1.tenu) {
            if (key[KEY_W]) objet1.pos_y -= 2; // Déplacer l'objet vers le haut
            if (key[KEY_S]) objet1.pos_y += 2; // Déplacer l'objet vers le bas
            if (key[KEY_A]) objet1.pos_x -= 2; // Déplacer l'objet vers la gauche
            if (key[KEY_D]) objet1.pos_x += 2; // Déplacer l'objet vers la droite
        }

        if (objet2.tenu) {
            if (key[KEY_W]) objet2.pos_y -= 2; // Déplacer l'objet 2 vers le haut
            if (key[KEY_S]) objet2.pos_y += 2; // Déplacer l'objet 2 vers le bas
            if (key[KEY_A]) objet2.pos_x -= 2; // Déplacer l'objet 2 vers la gauche
            if (key[KEY_D]) objet2.pos_x += 2; // Déplacer l'objet 2 vers la droite
        }


        if (key[KEY_C]) {
            if (objet1.tenu && abs(joueur1.pos_x - poubelle.pos_x- joueur1.rayon) < 20 && abs(joueur1.pos_y - poubelle.pos_y- joueur1.rayon) < 20) {
                objet1.tenu = 0; // L'objet est lâché
                objet1.pos_x = 5; // Retour à la position initiale
                objet1.pos_y = 50;
            }
        }

        if (key[KEY_C]) {
            if (objet2.tenu && abs(joueur1.pos_x - poubelle.pos_x- joueur1.rayon) < 20 && abs(joueur1.pos_y - poubelle.pos_y- joueur1.rayon) < 20) {
                objet2.tenu = 0; // L'objet est lâché
                objet2.pos_x = 10; // Retour à la position initiale
                objet2.pos_y = 430;
            }
        }

        if (key[KEY_L]) {
            if (objet1.tenu && abs(joueur2.pos_x - poubelle.pos_x- joueur2.rayon) < 20 && abs(joueur2.pos_y - poubelle.pos_y- joueur2.rayon) < 20) {
                objet1.tenu = 0; // L'objet est lâché
                objet1.pos_x = 5; // Retour à la position initiale
                objet1.pos_y = 50;
            }
        }

        if (key[KEY_L]) {
            if (objet2.tenu && abs(joueur2.pos_x - poubelle.pos_x- joueur2.rayon) < 20 && abs(joueur2.pos_y - poubelle.pos_y- joueur2.rayon) < 20) {
                objet2.tenu = 0; // L'objet est lâché
                objet2.pos_x = 10; // Retour à la position initiale
                objet2.pos_y = 430;
            }
        }

        /*if (key[KEY_C]) {
            if (objet1.tenu && abs(joueur1.pos_x - plaque.pos_x) < 20 && abs(joueur1.pos_y - plaque.pos_y) < 20) {
                // Placer l'objet sur la plaque
                objet1.tenu = 0;
                objet1.pos_x = plaque.pos_x;
                objet1.pos_y = plaque.pos_y;
                int cooking_timer = 0; // Timer de cuisson initialisé à 0

                // Attendre pendant 5 secondes pour simuler la cuisson
                while (cooking_timer < 5000) {
                    rest(10); // Attente de 10 millisecondes
                    cooking_timer += 10; // Incrémentation du timer
                }

                // Lorsque le temps de cuisson est écoulé
                // Changer l'objet en steak cuit
                // Remarque : vous devez avoir un bitmap pour l'objet steak cuit
                // Utilisez-le à la place de "objet" ci-dessous
                objet1 = steakcuit;
                objet1.tenu = 0; // Assurez-vous que l'objet n'est pas tenu après la cuisson
                objet1.pos_x = objet1_initial_x; // Réinitialisez la position de l'objet
                objet1.pos_y = objet1_initial_y;
            }
        }*/

        //ENREGISTRE POSITIONS

        // Mise à jour des positions des joueurs
        joueur1.pos_x += joueur1.dx;
        joueur1.pos_y += joueur1.dy;
        joueur2.pos_x += joueur2.dx;
        joueur2.pos_y += joueur2.dy;

        //COLISIONS MAP
        // circlefill(page, perso1.pos_x, perso1.pos_y, 15, makecol(255, 0, 0));

        //COLISIONS ENTRE LES JOUEURS

        // Vérification et ajustement des positions pour rester dans les limites de l'écran
        if (joueur1.pos_x < 0) joueur1.pos_x = 0;
        if (joueur1.pos_x > LARGEUR_ECRAN - joueur->w) joueur1.pos_x = LARGEUR_ECRAN - joueur->w;
        if (joueur1.pos_y < 0) joueur1.pos_y = 0;
        if (joueur1.pos_y > HAUTEUR_ECRAN - joueur->h) joueur1.pos_y = HAUTEUR_ECRAN - joueur->h;

        if (joueur2.pos_x < 0) joueur2.pos_x = 0;
        if (joueur2.pos_x > LARGEUR_ECRAN - joueur->w) joueur2.pos_x = LARGEUR_ECRAN - joueur->w;
        if (joueur2.pos_y < 0) joueur2.pos_y = 0;
        if (joueur2.pos_y > HAUTEUR_ECRAN - joueur->h) joueur2.pos_y = HAUTEUR_ECRAN - joueur->h;

        // Affichage des joueurs
        //draw_sprite(page, joueur, joueur1.pos_x, joueur1.pos_y);
        //draw_sprite(page, cuisinier, joueur2.pos_x, joueur2.pos_y);
        circlefill(page, joueur1.pos_x, joueur1.pos_y, joueur1.rayon, joueur1.couleur);
        circlefill(page, joueur2.pos_x, joueur2.pos_y, joueur2.rayon, joueur2.couleur);
        draw_sprite(page, PLAQUE, plaque.pos_x, plaque.pos_y);
        draw_sprite(page, POUBELLE, poubelle.pos_x, poubelle.pos_y);
        textout_ex(page, font, joueur1.pseudo, joueur1.pos_x, joueur1.pos_y - 20, makecol(0, 0, 0), -1);
        textout_ex(page, font, joueur2.pseudo, joueur2.pos_x, joueur2.pos_y - 20, makecol(0, 0, 0), -1);

        if (objet1.tenu) {
            if ((abs(joueur1.pos_x - objet1.pos_x) < 20 && abs(joueur1.pos_y - objet1.pos_y) < 20)) {
                objet1.pos_x = joueur1.pos_x;
                objet1.pos_y = joueur1.pos_y;
            } else if ((abs(joueur2.pos_x - objet1.pos_x) < 20 && abs(joueur2.pos_y - objet1.pos_y) < 20)) {
                objet1.pos_x = joueur2.pos_x;
                objet1.pos_y = joueur2.pos_y;
            }
            draw_sprite(page, objet, objet1.pos_x, objet1.pos_y);
        } else {
            // Dessiner l'objet à sa position initiale s'il n'est pas tenu
            draw_sprite(page, objet, objet1.pos_x, objet1.pos_y);
        }


        if (objet2.tenu) {
            if ((abs(joueur1.pos_x - objet2.pos_x) < 20 && abs(joueur1.pos_y - objet2.pos_y) < 20)) {
                objet2.pos_x = joueur2.pos_x;
                objet2.pos_y = joueur2.pos_y;
            } else if ((abs(joueur2.pos_x - objet2.pos_x) < 20 && abs(joueur2.pos_y - objet2.pos_y) < 20)) {
                objet2.pos_x = joueur2.pos_x;
                objet2.pos_y = joueur2.pos_y;
            }
            draw_sprite(page, Objet2, objet2.pos_x, objet2.pos_y);
        } else {
            // Dessiner l'objet à sa position initiale s'il n'est pas tenu
            draw_sprite(page, Objet2, objet2.pos_x, objet2.pos_y);
        }


        // Affichage sur l'écran
        blit(page, screen, 0, 0, 0, 0, LARGEUR_ECRAN, HAUTEUR_ECRAN);

        rest(10);

    }
    destroy_bitmap(page);
    destroy_bitmap(objet);
    destroy_bitmap(steakcuit);
    destroy_bitmap(Objet2);

    return 0;
}









