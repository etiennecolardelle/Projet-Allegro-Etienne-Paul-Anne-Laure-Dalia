#include "headers.h"

// Fonction pour gérer la sortie de cuisine
void sortie_cuisine() {
    int x = joueur1.pos_x / 40, y = joueur1.pos_y / 40 - 3;

    // Vérifier si le joueur est sur la case de sortie de cuisine (case 7)
    if (map[y][x] == 7) {
        // Parcourir la liste des commandes en attente
        Commande *courante = file.debut;
        Commande *precedante = NULL;

        while (courante != NULL) {
            // Vérifier si le plat déposé correspond à la commande courante
            if (joueur1.tenu_assiette != NULL && joueur1.tenu_assiette->ingrediants == courante->nb_ingrediant) {
                // Ajouter les points au score du joueur en fonction du nombre d'ingrédients de la commande
                score_joueur1.score += courante->nb_ingrediant * 10;

                // Ajouter les points au score de l'équipe
                score_equipe.scoreEquipe += courante->nb_ingrediant * 10;

                // Autres actions...

                break; // Sortir de la boucle une fois que la commande a été traitée
            }

            precedante = courante;
            courante = courante->suivante;
        }
    }
}