#include "headers.h"

void AnciennePosition1() {
    joueur1.old_posx = joueur1.pos_x;
    joueur1.old_posy = joueur1.pos_y;
    joueur1.pos_x+=joueur1.dx;
    joueur1.pos_y+=joueur1.dy;
}

void AnciennePosition2() {
    joueur2.old_posx = joueur2.pos_x;
    joueur2.old_posy = joueur2.pos_y;
    joueur2.pos_x+=joueur2.dx;
    joueur2.pos_y+=joueur2.dy;
}