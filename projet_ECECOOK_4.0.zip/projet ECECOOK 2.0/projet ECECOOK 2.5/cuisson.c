#include "headers.h"

/*void cuisson(){
    Aliment *aliment = file_ingrediant.debut;
    int x = aliment->pos_x/40, y=aliment->pos_y/40-3;
    if (map[y][x] == 2) {
        clock_t debut_cuisson = clock(); // Heure de début de la cuisson
        int duree_cuisson = 5; // Durée de la cuisson en secondes

        // Boucle pour la cuisson pendant la durée spécifiée
        while (((double)(clock() - debut_cuisson) / CLOCKS_PER_SEC) < duree_cuisson) {
            // Calcul du temps écoulé depuis le début de la cuisson
            double temps_ecoule = (double)(clock() - debut_cuisson) / CLOCKS_PER_SEC;
            aliment->cuisson += 1;
        }
    }
}*/

/* faire un timer avec une barre verte de chargement
         * qui diminue et qui se fini en mm temps que le temps passe
         * le socre le temps est fini le score de cuisson prend +1
         * */

void cuisson() {
    if((joueur1.tenu_assiette!=NULL)&&(joueur1.tenu_aliment!=NULL)) {
        Aliment *aliment = file_ingrediant.debut;
        int x=aliment->pos_x/40 , y=(aliment->pos_y/40)+3;
        while (aliment!=NULL)
        {
            if((aliment->cuisson>=1)&&(aliment->cuisson<=150)&&(map[x][y]==2)) {
                    aliment->cuisson++;
            }
            aliment = aliment->suivante;
        }

    }
}
