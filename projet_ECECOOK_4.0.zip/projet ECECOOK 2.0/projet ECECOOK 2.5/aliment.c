#include "headers.h"

/*
void poser_aliment() {
    int x = joueur1.pos_x / 40, y = joueur1.pos_y / 40 - 3;

    if (joueur1.action == 1 && joueur1.tenu_aliment != NULL) {
        if (map[y-1][x] == 1 || map[y-1][x] == 2 || map[y-1][x] == 3) {
            joueur1.tenu_aliment->pos_x = x * 40 + 20;
            joueur1.tenu_aliment->pos_y = y * 40 + 80 + 20;
            joueur1.tenu_aliment->tenu = 0;
            joueur1.tenu_aliment = NULL;
        } else if (map[y+1][x] == 1 || map[y+1][x] == 2 || map[y+1][x] == 3) {
            joueur1.tenu_aliment->pos_x = x * 40 + 20;
            joueur1.tenu_aliment->pos_y = y * 40 + 160 + 20;
            joueur1.tenu_aliment->tenu = 0;
            joueur1.tenu_aliment = NULL;
        } else if (map[y][x-1] == 1 || map[y][x-1] == 2 || map[y][x-1] == 3) {
            joueur1.tenu_aliment->pos_x = x * 40 - 40 + 20;
            joueur1.tenu_aliment->pos_y = y * 40 + 120 + 20;
            joueur1.tenu_aliment->tenu = 0;
            joueur1.tenu_aliment = NULL;
        } else if (map[y][x+1] == 1 || map[y][x+1] == 2 || map[y][x+1] == 3) {
            joueur1.tenu_aliment->pos_x = x * 40 + 40 + 20;
            joueur1.tenu_aliment->pos_y = y * 40 + 120 + 20;
            joueur1.tenu_aliment->tenu = 0;
            joueur1.tenu_aliment = NULL;
        }
    }

    if (joueur1.action == 1 && joueur1.tenu_assiette != NULL) {
        if (map[y-1][x] == 1) {
            joueur1.tenu_assiette->pos_x = x * 40 + 20;
            joueur1.tenu_assiette->pos_y = y * 40 + 80 + 20;
            joueur1.tenu_assiette->tenu = 0;
            joueur1.tenu_assiette = NULL;
        } else if (map[y+1][x] == 1) {
            joueur1.tenu_assiette->pos_x = x * 40 + 20;
            joueur1.tenu_assiette->pos_y = y * 40 + 160 + 20;
            joueur1.tenu_assiette->tenu = 0;
            joueur1.tenu_assiette = NULL;
        } else if (map[y][x-1] == 1) {
            joueur1.tenu_assiette->pos_x = x * 40 - 40 + 20;
            joueur1.tenu_assiette->pos_y = y * 40 + 120 + 20;
            joueur1.tenu_assiette->tenu = 0;
            joueur1.tenu_assiette = NULL;
        } else if (map[y][x+1] == 1) {
            joueur1.tenu_assiette->pos_x = x * 40 + 40 + 20;
            joueur1.tenu_assiette->pos_y = y * 40 + 120 + 20;
            joueur1.tenu_assiette->tenu = 0;
            joueur1.tenu_assiette = NULL;
        }
    }

    if (joueur1.action == 1 && joueur1.tenu_assiette == NULL && joueur1.tenu_aliment == NULL) {
        // DISTRIBUTEUR
        if (map[y - 1][x] == 8) {
            creation_aliment(1);
        }
        if (map[y + 1][x] == 8) {
            creation_aliment(1);
        }
        if (map[y][x + 1] == 8) {
            creation_aliment(1);
        }
        if (map[y][x - 1] == 8) {
            creation_aliment(1);
        }
    }
    if (joueur1.action == 1 && joueur1.tenu_assiette == NULL && joueur1.tenu_aliment == NULL) {
        if (map[y - 1][x] == 9) {
            creation_aliment(2);
        }
        if (map[y + 1][x] == 9) {
            creation_aliment(2);
        }
        if (map[y][x + 1] == 9) {
            creation_aliment(2);
        }
        if (map[y][x - 1] == 9) {
            creation_aliment(2);
        }
    }
    if (joueur1.action == 1 && joueur1.tenu_assiette == NULL && joueur1.tenu_aliment == NULL) {
        if (map[y - 1][x] == 4) {
            creation_aliment(3);
        }
        if (map[y + 1][x] == 4) {
            creation_aliment(3);
        }
        if (map[y][x + 1] == 4) {
            creation_aliment(3);
        }
        if (map[y][x - 1] == 4) {
            creation_aliment(3);
        }
    }
    if (joueur1.action == 1 && joueur1.tenu_assiette == NULL && joueur1.tenu_aliment == NULL) {
        if (map[y - 1][x] == 6) {
            creation_assiette();
        }
        if (map[y + 1][x] == 6) {
            creation_assiette();
        }
        if (map[y][x + 1] == 6) {
            creation_assiette();
        }
        if (map[y][x - 1] == 6) {
            creation_assiette();
        }
    }

    if (joueur1.action == 1 && joueur1.tenu_aliment == NULL && joueur1.tenu_assiette == NULL) {
        // PRENDRE AJOUTER ASSIETTE
        Aliment *taliment = file_ingrediant.debut;
        while (taliment != NULL) {
            if ((((joueur1.pos_x / 40) == (taliment->pos_x / 40)) &&
                 ((joueur1.pos_y / 40) - 1) == (taliment->pos_y / 40))
                || (((joueur1.pos_x / 40) == (taliment->pos_x / 40)) &&
                    ((joueur1.pos_y / 40) + 1) == (taliment->pos_y / 40))
                || ((((joueur1.pos_x / 40) + 1) == (taliment->pos_x / 40)) &&
                    (joueur1.pos_y / 40) == (taliment->pos_y / 40))
                || (((((joueur1.pos_x / 40) - 1)) == (taliment->pos_x / 40)) &&
                    (joueur1.pos_y / 40) == (taliment->pos_y / 40))) {
                joueur1.tenu_aliment = taliment;
                taliment->tenu = 1;
            }
            taliment = taliment->suivante;
        }
    }

    if (joueur1.action == 1 && joueur1.tenu_aliment == NULL && joueur1.tenu_assiette == NULL) {
        Assiette *tassiette = file_plat.debut;
        while (tassiette != NULL) {
            if ((((joueur1.pos_x / 40) == (tassiette->pos_x / 40)) &&
                 ((joueur1.pos_y / 40) - 1) == (tassiette->pos_y / 40))
                || (((joueur1.pos_x / 40) == (tassiette->pos_x / 40)) &&
                    ((joueur1.pos_y / 40) + 1) == (tassiette->pos_y / 40))
                || ((((joueur1.pos_x / 40) + 1) == (tassiette->pos_x / 40)) &&
                    (joueur1.pos_y / 40) == (tassiette->pos_y / 40))
                || (((((joueur1.pos_x / 40) - 1)) == (tassiette->pos_x / 40)) &&
                    (joueur1.pos_y / 40) == (tassiette->pos_y / 40))) {
                joueur1.tenu_assiette = tassiette;
                tassiette->tenu = 1;
            }
            tassiette = tassiette->suivante;
        }
    }
}*/


// Fonction de création d'une nouvelle assiette
void creation_aliment(int type){
    Aliment *aliment = malloc(sizeof(Aliment));
    aliment->type = type;

    if(joueur2.action==1) {
        aliment->tenu = 2;
        joueur2.tenu_aliment = aliment;
        joueur1.score += 5;
        score_equipe.scoreEquipe += 5;
        gestion_pos_objet();
    }
    else {
        aliment->tenu = 1;
        joueur1.tenu_aliment = aliment;
        joueur1.score += 5;
        score_equipe.scoreEquipe += 5;
        gestion_pos_objet();
    }
    aliment->suivante = NULL;
    // Si la file est vide, la nouvelle commande est à la fois le premier et le dernier élément
    if (file_ingrediant.debut == NULL) {
        file_ingrediant.debut = aliment;
        file_ingrediant.fin = aliment;
        aliment->precedante = NULL;
    } else {
        // Sinon, la nouvelle commande est ajoutée à la fin
        aliment->precedante = file_ingrediant.fin;
        file_ingrediant.fin->suivante = aliment;
        file_ingrediant.fin = aliment;
    }
}


void poser_aliment() {
    int x = joueur1.pos_x / 40, y = joueur1.pos_y / 40 - 3;

    if (joueur1.action == 1) {
        if (joueur1.tenu_assiette != NULL) {
            // Si devant une case avec un aliment
            if (map[y-1][x] == 4 || map[y+1][x] == 4 || map[y][x-1] == 4 || map[y][x+1] == 4) {
                Aliment *taliment = file_ingrediant.debut;
                while (taliment != NULL) {
                    if ((((joueur1.pos_x / 40) == (taliment->pos_x / 40)) &&
                         ((joueur1.pos_y / 40) - 1) == (taliment->pos_y / 40))
                        || (((joueur1.pos_x / 40) == (taliment->pos_x / 40)) &&
                            ((joueur1.pos_y / 40) + 1) == (taliment->pos_y / 40))
                        || ((((joueur1.pos_x / 40) + 1) == (taliment->pos_x / 40)) &&
                            (joueur1.pos_y / 40) == (taliment->pos_y / 40))
                        || (((((joueur1.pos_x / 40) - 1)) == (taliment->pos_x / 40)) &&
                            (joueur1.pos_y / 40) == (taliment->pos_y / 40))) {
                        joueur1.tenu_assiette->aliment = taliment;
                        taliment->tenu = 0;
                        taliment->pos_x = joueur1.tenu_assiette->pos_x;
                        taliment->pos_y = joueur1.tenu_assiette->pos_y;
                        file_ingrediant.debut = taliment->suivante; // Supprime l'aliment de la liste



                        break;
                    }

                    taliment = taliment->suivante;
                }
            }
        }
            // Si le joueur tient un aliment
        else if (joueur1.tenu_aliment != NULL) {
            // Poser l'aliment directement sur une case de type 1, 2 ou 3
            if (map[y-1][x] == 1 || map[y+1][x] == 1 || map[y][x-1] == 1 || map[y][x+1] == 1 ||
                map[y-1][x] == 2 || map[y+1][x] == 2 || map[y][x-1] == 2 || map[y][x+1] == 2 ||
                map[y-1][x] == 3 || map[y+1][x] == 3 || map[y][x-1] == 3 || map[y][x+1] == 3) {
                joueur1.tenu_aliment->pos_x = (map[y-1][x] == 1 || map[y-1][x] == 2 || map[y-1][x] == 3 ? x :
                                               map[y+1][x] == 1 || map[y+1][x] == 2 || map[y+1][x] == 3 ? x :
                                               map[y][x-1] == 1 || map[y][x-1] == 2 || map[y][x-1] == 3 ? x-1 : x+1) * 40 + 20;
                joueur1.tenu_aliment->pos_y = (map[y-1][x] == 1 || map[y-1][x] == 2 || map[y-1][x] == 3 ? y-1 :
                                               map[y+1][x] == 1 || map[y+1][x] == 2 || map[y+1][x] == 3 ? y+1 : y) * 40 + 20;
                joueur1.tenu_aliment->tenu = 0;
                joueur1.tenu_aliment = NULL;
            }
        }
            // Création des aliments et des assiettes depuis les distributeurs
        else {
            if (map[y-1][x] == 8 || map[y+1][x] == 8 || map[y][x-1] == 8 || map[y][x+1] == 8) {
                creation_aliment(1);
            } else if (map[y-1][x] == 9 || map[y+1][x] == 9 || map[y][x-1] == 9 || map[y][x+1] == 9) {
                creation_aliment(2);
            } else if (map[y-1][x] == 4 || map[y+1][x] == 4 || map[y][x-1] == 4 || map[y][x+1] == 4) {
                creation_aliment(3);
            } else if (map[y-1][x] == 6 || map[y+1][x] == 6 || map[y][x-1] == 6 || map[y][x+1] == 6) {
                creation_assiette();
            }
        }

        // Prendre un aliment ou une assiette au sol
        if (joueur1.tenu_aliment == NULL && joueur1.tenu_assiette == NULL) {
            Aliment *taliment = file_ingrediant.debut;
            while (taliment != NULL) {
                if ((((joueur1.pos_x / 40) == (taliment->pos_x / 40)) &&
                     ((joueur1.pos_y / 40) - 1) == (taliment->pos_y / 40))
                    || (((joueur1.pos_x / 40) == (taliment->pos_x / 40)) &&
                        ((joueur1.pos_y / 40) + 1) == (taliment->pos_y / 40))
                    || ((((joueur1.pos_x / 40) + 1) == (taliment->pos_x / 40)) &&
                        (joueur1.pos_y / 40) == (taliment->pos_y / 40))
                    || (((((joueur1.pos_x / 40) - 1)) == (taliment->pos_x / 40)) &&
                        (joueur1.pos_y / 40) == (taliment->pos_y / 40))) {
                    joueur1.tenu_aliment = taliment;
                    taliment->tenu = 1;
                    break;
                }
                taliment = taliment->suivante;
            }

            Assiette *tassiette = file_plat.debut;
            while (tassiette != NULL) {
                if ((((joueur1.pos_x / 40) == (tassiette->pos_x / 40)) &&
                     ((joueur1.pos_y / 40) - 1) == (tassiette->pos_y / 40))
                    || (((joueur1.pos_x / 40) == (tassiette->pos_x / 40)) &&
                        ((joueur1.pos_y / 40) + 1) == (tassiette->pos_y / 40))
                    || ((((joueur1.pos_x / 40) + 1) == (tassiette->pos_x / 40)) &&
                        (joueur1.pos_y / 40) == (tassiette->pos_y / 40))
                    || (((((joueur1.pos_x / 40) - 1)) == (tassiette->pos_x / 40)) &&
                        (joueur1.pos_y / 40) == (tassiette->pos_y / 40))) {
                    joueur1.tenu_assiette = tassiette;
                    tassiette->tenu = 1;
                    break;
                }
                tassiette = tassiette->suivante;
            }
        }
    }
}

/*
 * // Poser l'assiette sur une case de type 1
            if (map[y-1][x] == 1 || map[y+1][x] == 1 || map[y][x-1] == 1 || map[y][x+1] == 1) {
                joueur1.tenu_assiette->pos_x = (map[y-1][x] == 1 ? x : map[y+1][x] == 1 ? x : map[y][x-1] == 1 ? x-1 : x+1) * 40 + 20;
                joueur1.tenu_assiette->pos_y = (map[y-1][x] == 1 ? y-1 : map[y+1][x] == 1 ? y+1 : y) * 40 + 20;
                joueur1.tenu_assiette->tenu = 0;
                joueur1.tenu_assiette = NULL;
            }
 */