#include "headers.h"

/*
// Fonction de création d'une nouvelle assiette
void creation_assiette(){
    Assiette *assiette = malloc(sizeof(Assiette));
    assiette->ingrediants=0;

    if(joueur2.action==1) {
        assiette->tenu = 1;
        joueur2.tenu_assiette = assiette;
        gestion_pos_objet();
    }
    else {
        assiette->tenu = 1;
        joueur1.tenu_assiette = assiette;
        gestion_pos_objet();
    }

    assiette->suivante = NULL;
    // Si la file est vide, la nouvelle commande est à la fois le premier et le dernier élément
    if (file_plat.debut == NULL) {
        file_plat.debut = assiette;
        file_plat.fin = assiette;
        assiette->precedante = NULL;
    } else {
        // Sinon, la nouvelle commande est ajoutée à la fin
        assiette->precedante = file_plat.fin;
        file_plat.fin->suivante = assiette;
        file_plat.fin = assiette;
    }
}
*/

// Fonction de création d'une nouvelle assiette
void creation_assiette() {
    Assiette *assiette = malloc(sizeof(Assiette));
    assiette->ingrediants = 0;
    assiette->tenu = 1;
    assiette->aliment = NULL; // Ajouter cette ligne pour gérer l'aliment sur l'assiette
    assiette->suivante = NULL;

    if (joueur1.action == 1 && joueur1.tenu_assiette == NULL) {
        joueur1.tenu_assiette = assiette;
        joueur1.score += 5;
        score_equipe.scoreEquipe += 5;

    } else if (joueur2.action == 1 && joueur2.tenu_assiette == NULL) {
        joueur2.tenu_assiette = assiette;
        joueur1.score += 5;
        score_equipe.scoreEquipe += 5;
    } else {
        free(assiette); // Pas besoin de l'assiette si aucun joueur ne peut la prendre
        return;
    }

    // Ajouter l'assiette à la file des plats
    if (file_plat.debut == NULL) {
        file_plat.debut = assiette;
        file_plat.fin = assiette;
        assiette->precedante = NULL;
    } else {
        assiette->precedante = file_plat.fin;
        file_plat.fin->suivante = assiette;
        file_plat.fin = assiette;
    }
}


