#include "headers.h"

void chargement_personnage(){
    personnage[0] = load_bitmap("image/personnage/cuisinier_face_a_droite.bmp", NULL);
    personnage[1] = load_bitmap("image/personnage/cuisinier_face_diagonale_avant_droite.bmp", NULL);
    personnage[2] = load_bitmap("image/personnage/cuisinier_face_diagonale_derriere_droite.bmp", NULL);
    personnage[3] = load_bitmap("image/personnage/cuisinier_face_gauche.bmp", NULL);
    personnage[4] = load_bitmap("image/personnage/cuisinier_face_oppose.bmp", NULL);
    personnage[5] = load_bitmap("image/personnage/cusinier_face_a_nous.bmp", NULL);
}
