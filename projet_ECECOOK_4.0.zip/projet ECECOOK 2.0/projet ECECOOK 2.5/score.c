#include "headers.h"

void afficher_scores() {
    // Afficher le pseudo et le score du joueur 1
    char scoreJoueur1[100];
    sprintf(scoreJoueur1, "Score: %d", joueur1.score);
    textout_ex(page, font, scoreJoueur1, joueur1.pos_x-30, joueur1.pos_y+20, makecol(255, 255, 255), -1);

    // Afficher le pseudo et le score du joueur 2
    char scoreJoueur2[100];
    sprintf(scoreJoueur2, "Score: %d", joueur2.score);
    textout_ex(page, font, scoreJoueur2, joueur2.pos_x-30, joueur2.pos_y+20, makecol(255, 255, 255), -1);

    // Afficher le score de l'équipe à une position spécifique sur la carte
    int x = 340; // Exemple de coordonnée X sur la carte
    int y = 110;  // Exemple de coordonnée Y sur la carte
    char scoreEquipe[100];
    sprintf(scoreEquipe, "Score d'équipe: %d", score_equipe);
    textout_ex(page, font, scoreEquipe, x, y, makecol(255, 255, 255), -1);

}
