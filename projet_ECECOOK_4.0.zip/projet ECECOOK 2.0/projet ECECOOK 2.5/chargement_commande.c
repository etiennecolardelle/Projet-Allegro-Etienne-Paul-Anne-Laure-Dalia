#include "headers.h"

void charger_commandes() {
    affiche[0] = load_bitmap("image/commande/planche.bmp", NULL);
    affiche[1] = load_bitmap("image/commande/planche2.bmp", NULL);
    affiche[2] = load_bitmap("image/commande/planche3.bmp", NULL);

    affiche_demande[0] = load_bitmap("image/commande/aliment/bolchampignon.bmp", NULL);
    affiche_demande[1] = load_bitmap("image/commande/aliment/boloignon.bmp", NULL);
    affiche_demande[2] = load_bitmap("image/commande/aliment/bol_tomate.bmp", NULL);

    nourriture[0] = load_bitmap("image/commande/assiette.bmp", NULL);
    nourriture[1] = load_bitmap("image/commande/oignon.bmp", NULL);
    nourriture[2] = load_bitmap("image/commande/tomate.bmp", NULL);
    nourriture[3] = load_bitmap("image/commande/champignon.bmp", NULL);

}

void charger_commandes2() {
    affiche[0] = load_bitmap("image/commande/planche.bmp", NULL);
    affiche[1] = load_bitmap("image/commande/planche2.bmp", NULL);
    affiche[2] = load_bitmap("image/commande/planche3.bmp", NULL);

    affiche_demande[0] = load_bitmap("image/commande/aliment2/sushi.bmp", NULL);
    affiche_demande[1] = load_bitmap("image/commande/aliment2/sushi.bmp", NULL);
    affiche_demande[2] = load_bitmap("image/commande/aliment2/riz_seul.bmp", NULL);

    nourriture[0] = load_bitmap("image/commande/assiette.bmp", NULL);
    nourriture[1] = load_bitmap("image/commande/saumon.bmp", NULL);
    nourriture[2] = load_bitmap("image/commande/riz.bmp", NULL);
    nourriture[3] = load_bitmap("image/commande/algue.bmp", NULL);

}

void charger_commandes3() {
    affiche[0] = load_bitmap("image/commande/planche.bmp", NULL);
    affiche[1] = load_bitmap("image/commande/planche2.bmp", NULL);
    affiche[2] = load_bitmap("image/commande/planche3.bmp", NULL);

    affiche_demande[0] = load_bitmap("image/commande/aliment3/poulet_frite_sauce.bmp", NULL);
    affiche_demande[1] = load_bitmap("image/commande/aliment3/poulet_frite.bmp", NULL);
    affiche_demande[2] = load_bitmap("image/commande/aliment3/poulet_sur_asssiete.bmp", NULL);

    nourriture[0] = load_bitmap("image/commande/assiette.bmp", NULL);
    nourriture[1] = load_bitmap("image/commande/frites.bmp", NULL);
    nourriture[2] = load_bitmap("image/commande/poulet.bmp", NULL);
    nourriture[3] = load_bitmap("image/commande/sauce.bmp", NULL);

}