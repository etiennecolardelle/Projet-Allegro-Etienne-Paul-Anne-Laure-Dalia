#include "headers.h"

void decoupe() {
    if((joueur1.action==2)&&(joueur1.tenu_assiette!=NULL)&&(joueur1.tenu_aliment!=NULL)) {
        Aliment *aliment = file_ingrediant.debut;
        int x=aliment->pos_x/40 , y=(aliment->pos_y/40)+3;
        while (aliment!=NULL)
        {
            if((aliment->decoupe>=1)&&(aliment->decoupe<=150)&&(map[x][y]==2)){
                if((((joueur1.pos_x / 40) == (aliment->pos_x / 40))&&((joueur1.pos_y / 40) - 1) == (aliment->pos_y / 40))||(((joueur1.pos_x / 40) == (aliment->pos_x / 40)) && ((joueur1.pos_y / 40) + 1) == (aliment->pos_y / 40))||((((joueur1.pos_x / 40)+1) == (aliment->pos_x / 40)) && (joueur1.pos_y / 40) == (aliment->pos_y / 40))||((((joueur1.pos_x / 40)-1) == (aliment->pos_x / 40)) && (joueur1.pos_y / 40) == (aliment->pos_y / 40)))
                {
                    aliment->decoupe++;
                }
            }
            aliment = aliment->suivante;
        }
    }
}


