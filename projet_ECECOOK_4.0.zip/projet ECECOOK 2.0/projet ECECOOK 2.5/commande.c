#include "headers.h"

/*
float mesure_temp(int debut,int fin){
    return ((float) (fin - debut)) / CLOCKS_PER_SEC;
}

void commande() {
    debut_commande = clock_t;
    commande1 = load_bitmap("image/jeu/image_jeu.bmp", NULL);
    commande2 = load_bitmap("image/jeu/image_jeu.bmp", NULL);
    commande3 = load_bitmap("image/jeu/image_jeu.bmp", NULL);
    commande4 = load_bitmap("image/jeu/image_jeu.bmp", NULL);

}*/


#include "headers.h"

void ajouter_commande() {
    Commande *nouvelle_commande = malloc(sizeof(Commande));
    if (nouvelle_commande == NULL) {
        fprintf(stderr, "Erreur d'allocation de mémoire.\n");
        return;
    }
    nouvelle_commande->nb_ingrediant = rand() % (4 - 2 + 1) + 2;  // nombre aléatoire entre 2 et 4
    nouvelle_commande->temps_com = clock();
    nouvelle_commande->suivante = NULL;

    if (file.debut == NULL) {  // Vérifie si la file est vide
        file.debut = nouvelle_commande;
        file.fin = nouvelle_commande;
        nouvelle_commande->precedante = NULL;
    } else {
        nouvelle_commande->precedante = file.fin;
        file.fin->suivante = nouvelle_commande;
        file.fin = nouvelle_commande;
    }
}

void charger_commandes();

void dessiner_commandes() {
    int x_position = 5;
    Commande *actuelle = file.debut;
    while (actuelle != NULL) {
        int temps_ecoule = ((float)(clock() - actuelle->temps_com)) / CLOCKS_PER_SEC;
        int temps_rest = 30 - temps_ecoule;
        int bar_length = 100 - (temps_ecoule * 100 / 30);

        switch (actuelle->nb_ingrediant) {
            case 2:
                draw_sprite(page, affiche[0], x_position, 0);
                draw_sprite(page, affiche_demande[2], x_position + 25, 14);
                draw_sprite(page, nourriture[0], x_position + 5, 65);
                draw_sprite(page, nourriture[2], x_position + 15, 73);
                rectfill(page, x_position + 1, 0, x_position + 104 - bar_length, 16, makecol(255 * temps_ecoule / 30, 255 - 255 * temps_ecoule / 30, 0));
                x_position += 110;
                break;
            case 3:
                draw_sprite(page, affiche[1], x_position, 0);
                draw_sprite(page, affiche_demande[1], x_position + 50, 14);
                draw_sprite(page, nourriture[0], x_position + 5, 65);
                draw_sprite(page, nourriture[0], x_position + 53, 65);
                draw_sprite(page, nourriture[1], x_position + 15, 73);
                draw_sprite(page, nourriture[2], x_position + 66, 73);
                rectfill(page, x_position + 1, 0, x_position + 152 - bar_length, 16, makecol(255 * temps_ecoule / 30, 255 - 255 * temps_ecoule / 30, 0));
                x_position += 157;
                break;
            case 4:
                draw_sprite(page, affiche[2], x_position, 0);
                draw_sprite(page, affiche_demande[0], x_position + 74, 14);
                draw_sprite(page, nourriture[0], x_position + 5, 65);
                draw_sprite(page, nourriture[0], x_position + 53, 65);
                draw_sprite(page, nourriture[0], x_position + 101, 65);
                draw_sprite(page, nourriture[1], x_position + 15, 73);
                draw_sprite(page, nourriture[2], x_position + 66, 73);
                draw_sprite(page, nourriture[3], x_position + 114, 73);
                rectfill(page, x_position + 1, 0, x_position + 201 - bar_length, 16, makecol(255 * temps_ecoule / 30, 255 - 255 * temps_ecoule / 30, 0));
                x_position += 206;
                break;
        }
        actuelle = actuelle->suivante;
    }
}

void retirer_commande() {
    if (file.debut == NULL) {  // Vérifie si la file est vide
        fprintf(stderr, "La file est vide.\n");
        return;
    }
    Commande *commande = file.debut;
    file.debut = file.debut->suivante;
    if (file.debut == NULL) {
        file.fin = NULL;
    } else {
        file.debut->precedante = NULL;
    }
    free(commande);
}

void mettre_a_jour_commandes() {
    int temps_ecoule = ((float)(clock() - debut_commande)) / CLOCKS_PER_SEC;
    if (temps_ecoule > rand() % (10 - 5 + 1) + 5) {  // intervalle aléatoire entre 5 et 10
        ajouter_commande();
        debut_commande = clock();
    }
}

void verifier_temps_commandes() {
    Commande *actuelle = file.debut;
    while (actuelle != NULL) {
        if (((float)(clock() - actuelle->temps_com)) / CLOCKS_PER_SEC > 30) {
            Commande *temp = actuelle;
            if (actuelle != NULL) {
                actuelle->suivante = actuelle->suivante;
            } else {
                file.debut = actuelle->suivante;
            }
            if (actuelle->suivante != NULL) {
                actuelle->suivante->precedante = actuelle;
            }
            actuelle = actuelle->suivante;
            free(temp);
        } else {
            actuelle = actuelle;
            actuelle = actuelle->suivante;
        }
    }
}
