#include "headers.h"

int initialisation(){
    // Initialisation des positions des joueurs
    joueur1.pos_x = 150,joueur1.pos_y = 300, joueur1.rayon=15,joueur1.couleur= makecol(100,100,100);
    joueur2.pos_x = 600,joueur2.pos_y = 300, joueur2.rayon=15,joueur2.couleur= makecol(200,200,200);

    /*objet1.pos_x =  5; // Position initiale de l'objet
    objet1.pos_y = 50;
    objet1.tenu = 0; // L'objet n'est pas encore tenu par un joueur

    objet2.pos_x =  10; // Position initiale de l'objet
    objet2.pos_y = 430;
    objet2.tenu = 0; // L'objet n'est pas encore tenu par un joueur

    poubelle.pos_x = 300;
    poubelle.pos_y = 400;

    plaque.pos_x = 370;
    plaque.pos_y = 150;*/

    joueur1.tenu_assiette = NULL;
    joueur1.tenu_aliment = NULL;

    // Initialisation des scores au début du jeu
    score_joueur1.score = 0;
    score_joueur2.score = 0;
    score_equipe.scoreEquipe = 0;
}
