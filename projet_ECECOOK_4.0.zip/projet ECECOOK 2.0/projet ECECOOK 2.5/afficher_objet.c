#include "headers.h"

/*
void afficher(){
    Assiette *tenu_assiette = file_plat.debut;
    while (tenu_assiette != NULL){
        circlefill(page, tenu_assiette->pos_x, tenu_assiette->pos_y, 10,makecol(255,255,255) );
        tenu_assiette = tenu_assiette->suivante;
    }

    Aliment *tenu_aliment = file_ingrediant.debut;
    while (tenu_aliment != NULL){
        circlefill(page, tenu_aliment->pos_x, tenu_aliment->pos_y, 6,makecol(255,100,0) );
        tenu_aliment = tenu_aliment->suivante;
    }
}*/

void afficher() {
    Assiette *tenu_assiette = file_plat.debut;
    while (tenu_assiette != NULL) {
        //draw_sprite(page, , tenu_assiette->pos_x-10, tenu_assiette->pos_y-10);
        circlefill(page, tenu_assiette->pos_x, tenu_assiette->pos_y, 10, makecol(255, 255, 255));
        tenu_assiette = tenu_assiette->suivante;
    }

    Aliment *tenu_aliment = file_ingrediant.debut;
    while (tenu_aliment != NULL) {
        int color;
        switch (tenu_aliment->type) {
            case 1:
                //color = makecol(255, 0, 0); // Orange
                draw_sprite(page,nourriture[1] , tenu_aliment->pos_x-6, tenu_aliment->pos_y-6);
                break;
            case 2:
                color = makecol(0, 255, 0); // Vert
                draw_sprite(page,nourriture[2] , tenu_aliment->pos_x-6, tenu_aliment->pos_y-6);
                break;
            case 3:
                color = makecol(100, 0, 255); // Bleu
                draw_sprite(page,nourriture[3] , tenu_aliment->pos_x-6, tenu_aliment->pos_y-6);
                break;
        }

        //circlefill(page, tenu_aliment->pos_x, tenu_aliment->pos_y, 6, color);
        tenu_aliment = tenu_aliment->suivante;
    }
}
