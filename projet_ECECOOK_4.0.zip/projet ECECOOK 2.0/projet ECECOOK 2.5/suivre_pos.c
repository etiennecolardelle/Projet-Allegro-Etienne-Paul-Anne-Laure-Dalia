#include "headers.h"

void suivie_pos(){
    if (joueur1.tenu_assiette!=NULL){
        joueur1.tenu_assiette->pos_x=joueur1.pos_x;
        joueur1.tenu_assiette->pos_y=joueur1.pos_y;
    }
    if (joueur1.tenu_aliment!=NULL){
        joueur1.tenu_aliment->pos_x=joueur1.pos_x;
        joueur1.tenu_aliment->pos_y=joueur1.pos_y;
    }
}