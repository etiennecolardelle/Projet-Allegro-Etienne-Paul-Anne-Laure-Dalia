#include "headers.h"

void Action(){
    joueur1.action=0,joueur2.action=0;
    if (key[KEY_C]) joueur1.action=1;
    else if(key[KEY_V]) joueur1.action=2;

    if(key[KEY_L]) joueur2.action=1;
    else if(key[KEY_M]) joueur2.action=2;
}