
#ifndef PROJET_ECECOOK_HEADERS_H
#define PROJET_ECECOOK_HEADERS_H

#include <allegro.h>
#include <math.h>
#include <time.h>
#include <stdio.h>

#define LARGEUR_ECRAN 800
#define HAUTEUR_ECRAN 600
#define NB_DECOUPE 100

BITMAP *page;
BITMAP *jeu;
BITMAP *joueur;
BITMAP *cuisinier;
BITMAP *pseudo;
BITMAP *regle;
BITMAP *niveau[5];
BITMAP *objet;
BITMAP *Objet2;
BITMAP *POUBELLE;
BITMAP *steakcuit;
BITMAP *PLAQUE;
BITMAP *image_menu[10];
BITMAP *affiche[3];
BITMAP *affiche_demande[5];
BITMAP *nourriture[5];
BITMAP *personnage[7];

// Structure commande
typedef struct Commande {
    int nb_ingrediant;
    long temps_com; // temps pour servir la commande avant expiration
    struct Commande *suivante; //pointeur vers la prochaine commande
    struct Commande *precedante; //pointeur vers la commande précedante
} Commande;


typedef struct {
    char pseudo[50];
    int pos_x, pos_y;
    int dx, dy;
    int action;
    int rayon;
    int couleur;
    int old_posx, old_posy;
    struct Assiette *tenu_assiette;
    struct Aliment *tenu_aliment;
    struct Aliment2 *tenu_aliment2;
    struct Aliment3 *tenu_aliment3;
    int score;
}Personnage;

typedef struct Aliment {
    int pos_x, pos_y;
    int dx, dy;
    int tenu; // 1 si tenu par un joueur sinon 0
    int cuisson, decoupe;
    struct Aliment *suivante; //pointeur vers la prochain objet
    struct Aliment *precedante; //pointeur vers l'objet précedant
    int type;
}Aliment;

typedef struct Assiette{
    int ingrediants;
    int pos_x, pos_y;
    int rayon;
    int couleur;
    int tenu;
    struct Aliment *aliment;
    struct Assiette *suivante; //pointeur vers la prochaine assiette
    struct Assiette *precedante; //pointeur vers l'assiette précedante
} Assiette;

typedef struct {
    Assiette *debut;
    Assiette *fin;
} File_plat;

typedef struct {
    Commande *debut;
    Commande *fin;
} File_commande;

typedef struct {
    Aliment *debut;
    Aliment *fin;
} File_ingrediant;

typedef struct {
    int score;
} ScoreJoueur;

// Structure pour les scores d'équipe
typedef struct {
    int scoreEquipe;
} ScoreEquipe;


clock_t debut_jeu, fin_jeu, debut_commande;
Personnage joueur1;
Personnage joueur2;
File_plat file_plat;
File_commande file;
File_ingrediant file_ingrediant;
ScoreJoueur score_joueur1;
ScoreJoueur score_joueur2;
ScoreEquipe score_equipe;

int map[12][20];

//INITILISATION
int initialisation();
void init_map();
void init_map2();
void init_map3();
void check_collision();

//ACTION
void decoupe();
void cuisson();
void Action();

//POSITION
void gestion_mouv();
void gestion_pos_objet();
void AnciennePosition1();
void AnciennePosition2();
void suivie_pos();

//OBJET
void creation_assiette();
void afficher();
void creation_aliment(int type);
void poser_aliment();
void poser_objet();

//chargement des images
void chargement_IN();
void chargement_IJ();
void chargement_IM();
void chargement_personnage();

//COMMANDE
void ajouter_commande();
void charger_commandes();
void charger_commandes2();
void charger_commandes3();
void dessiner_commandes();
void retirer_commande();
void mettre_a_jour_commandes();
void verifier_temps_commandes();

//MENU
void menu();
int jouer();
int Pseudo();
int RegleDuJeu();
int chargementniveau();
int quitter();
int Niveau1();
int Niveau2();
int Niveau3();

//SCORE
void afficher_scores();

#endif //PROJET_ECECOOK_HEADERS_H


