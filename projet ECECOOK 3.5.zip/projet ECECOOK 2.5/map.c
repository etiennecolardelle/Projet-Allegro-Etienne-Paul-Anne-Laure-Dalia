#include "headers.h"

void init_map() {
    int carte[12][20] = {
            1,1,3,1,3,1,1,1,1,7,7,1,1,1,6,1,1,5,1,1,
            1,0,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,1,
            1,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,
            1,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,
            1,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,
            1,0,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,1,
            1,0,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,1,
            1,0,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,1,
            1,0,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,1,
            1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,1,
            1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,1,
            1,1,2,2,2,1,1,1,1,1,1,1,1,1,4,1,9,1,8,1,
    };

    for (int i = 0; i < 12; ++i) {
        for (int j = 0; j < 20; ++j) {
            map[i][j] = carte[i][j];
        }
    }
}

void check_collision() {
    int m1[8][2], m2[8][2];

    m1[0][0] = joueur1.pos_x / 40, m1[0][1] = ((joueur1.pos_y + 15) / 40)-3;    //NORD
    m1[1][0] = joueur1.pos_x / 40, m1[1][1] = ((joueur1.pos_y - 15) / 40)-3;    //SUD
    m1[2][0] = (joueur1.pos_x + 15) / 40, m1[2][1] = (joueur1.pos_y / 40)-3;    //EST
    m1[3][0] = (joueur1.pos_x - 15) / 40, m1[3][1] = (joueur1.pos_y / 40)-3;    //OUEST
    m1[4][0] = (joueur1.pos_x - 12) / 40, m1[4][1] = ((joueur1.pos_y + 12) / 40)-3; //NORD-OUEST
    m1[5][0] = (joueur1.pos_x + 12) / 40, m1[5][1] = ((joueur1.pos_y - 12) / 40)-3; //SUD-EST
    m1[6][0] = (joueur1.pos_x - 12) / 40, m1[6][1] = ((joueur1.pos_y - 12) / 40)-3; //SUD-OUEST
    m1[7][0] = (joueur1.pos_x + 12) / 40, m1[7][1] = ((joueur1.pos_y + 12) / 40)-3; //NORD-EST

    m2[0][0] = joueur2.pos_x / 40, m2[0][1] = ((joueur2.pos_y + 15) / 40)-3;  //NORD
    m2[1][0] = joueur2.pos_x / 40, m2[1][1] = ((joueur2.pos_y - 15) / 40)-3;  //SUD
    m2[2][0] = (joueur2.pos_x + 15) / 40, m2[2][1] = (joueur2.pos_y / 40)-3;  //EST
    m2[3][0] = (joueur2.pos_x - 15) / 40, m2[3][1] = (joueur2.pos_y / 40)-3;  //OUEST
    m2[4][0] = (joueur2.pos_x - 12) / 40, m2[4][1] = ((joueur2.pos_y + 12) / 40)-3;    //NORD_OUEST
    m2[5][0] = (joueur2.pos_x + 12) / 40, m2[5][1] = ((joueur2.pos_y - 12) / 40)-3;    //SUD_EST
    m2[6][0] = (joueur2.pos_x - 12) / 40, m2[6][1] = ((joueur2.pos_y - 12) / 40)-3;    //SUD_OUEST
    m2[7][0] = (joueur2.pos_x + 12) / 40, m2[7][1] = ((joueur2.pos_y + 12) / 40)-3;    //NORD-EST


    for (int i = 0; i < 8; ++i) {
        if ((map[m1[i][1]][m1[i][0]]) != 0) {
            joueur1.pos_x = joueur1.old_posx, joueur1.pos_y = joueur1.old_posy;
        }
        if ((map[m2[i][1]][m2[i][0]])!= 0) {
            joueur2.pos_x = joueur2.old_posx, joueur2.pos_y = joueur2.old_posy;
        }
    }
    if ((sqrt((joueur1.pos_x- joueur2.pos_x)*(joueur1.pos_x-joueur2.pos_x)+(joueur1.pos_y-joueur2.pos_y)*(joueur1.pos_y-joueur2.pos_y)))<=30) {
        joueur1.pos_x = joueur1.old_posx, joueur1.pos_y = joueur1.old_posy;
        joueur2.pos_x = joueur2.old_posx, joueur2.pos_y = joueur2.old_posy;
    }
}

