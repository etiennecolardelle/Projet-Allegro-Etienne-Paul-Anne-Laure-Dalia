#include "headers.h"

void chargement_IN(){
    niveau[0] = load_bitmap("image/NIVEAU/niveau.bmp", NULL);
    niveau[1] = load_bitmap("image/NIVEAU/niveau1.bmp", NULL);
    niveau[2] = load_bitmap("image/NIVEAU/niveau2.bmp", NULL);
    niveau[3] = load_bitmap("image/NIVEAU/niveau3.bmp", NULL);
}