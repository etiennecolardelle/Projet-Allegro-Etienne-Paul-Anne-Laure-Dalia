#include "headers.h"

/*
void fonction_poubelle(){
    if (key[KEY_C]) {
        if (objet1.tenu && abs(joueur1.pos_x - poubelle.pos_x- joueur1.rayon) < 20 && abs(joueur1.pos_y - poubelle.pos_y- joueur1.rayon) < 20) {
            objet1.tenu = 0; // L'objet est lâché
            objet1.pos_x = 5; // Retour à la position initiale
            objet1.pos_y = 50;
        }
    }

    if (key[KEY_C]) {
        if (objet2.tenu && abs(joueur1.pos_x - poubelle.pos_x- joueur1.rayon) < 20 && abs(joueur1.pos_y - poubelle.pos_y- joueur1.rayon) < 20) {
            objet2.tenu = 0; // L'objet est lâché
            objet2.pos_x = 10; // Retour à la position initiale
            objet2.pos_y = 430;
        }
    }

    if (key[KEY_L]) {
        if (objet1.tenu && abs(joueur2.pos_x - poubelle.pos_x- joueur2.rayon) < 20 && abs(joueur2.pos_y - poubelle.pos_y- joueur2.rayon) < 20) {
            objet1.tenu = 0; // L'objet est lâché
            objet1.pos_x = 5; // Retour à la position initiale
            objet1.pos_y = 50;
        }
    }

    if (key[KEY_L]) {
        if (objet2.tenu && abs(joueur2.pos_x - poubelle.pos_x- joueur2.rayon) < 20 && abs(joueur2.pos_y - poubelle.pos_y- joueur2.rayon) < 20) {
            objet2.tenu = 0; // L'objet est lâché
            objet2.pos_x = 10; // Retour à la position initiale
            objet2.pos_y = 430;
        }
    }
}


void fonction_poubelle(){
    int x = joueur1.pos_x/40, y=joueur1.pos_y/40;
    if ((joueur1.prendre==1)&&(joueur1.tenu!=NULL)&&(map[y-1][x]==8))
        joueur1.tenu=0;
}
*/



