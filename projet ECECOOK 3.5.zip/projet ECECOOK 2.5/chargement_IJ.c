#include "headers.h"

void chargement_IJ(){
    // Load images
    jeu = load_bitmap("image/jeu/image_jeu.bmp", NULL);
    joueur = load_bitmap("image/jeu/joueur.bmp", NULL);
    objet = load_bitmap("image/jeu/steak.bmp", NULL);
    Objet2 = load_bitmap("image/jeu/salade.bmp", NULL);
    steakcuit = load_bitmap("image/jeu/steakcuit.bmp", NULL);
    POUBELLE = load_bitmap("image/jeu/poubelle.bmp", NULL);
    PLAQUE = load_bitmap("image/jeu/plaque.bmp", NULL);
    cuisinier = load_bitmap("image/jeu/cuisinier2.bmp", NULL);
}