#include "headers.h"


int Niveau1(){
    jouer();
}

int Niveau2(){
  // Déclaration des variables pour le timer
    clock_t debut_partie, fin_partie;
    int duree_partie = 90; // Durée de la partie en secondes (2 minutes)

    clear_bitmap(screen);
    // Load images
    chargement_IJ();
    charger_commandes();
    initialisation();
    init_map();
    debut_jeu = clock();
    debut_partie = clock(); // Initialisation du timer de la partie
    ajouter_commande();
    while (!key[KEY_CAPSLOCK]) {
        // Calcul du temps écoulé depuis le début de la partie
        fin_partie = clock();
        double temps_ecoule = (double)(fin_partie - debut_partie) / CLOCKS_PER_SEC;

        // Vérification si le temps écoulé dépasse la durée de la partie
        if (temps_ecoule >= duree_partie) {
            menu();
            //liberer la memoire avant
            break;
        }

        clear_bitmap(page);
        blit(jeu, page, 0, 0, 0, 120, jeu->w, jeu->h);

        //prendre_lacher();
        //deplacer_objet();
        //fonction_poubelle();

        //MOUVEMENT
        gestion_mouv();

        //ENREGISTRE POSITIONS
        AnciennePosition1();
        AnciennePosition2();

        // Mise à jour des positions des joueurs
        joueur1.pos_x += joueur1.dx;
        joueur1.pos_y += joueur1.dy;
        joueur2.pos_x += joueur2.dx;
        joueur2.pos_y += joueur2.dy;

        //ACTION
        Action();

        //COLISIONS
        check_collision();

        circlefill(page, joueur1.pos_x, joueur1.pos_y, joueur1.rayon, joueur1.couleur);
        circlefill(page, joueur2.pos_x, joueur2.pos_y, joueur2.rayon, joueur2.couleur);
        textout_ex(page, font, joueur1.pseudo, joueur1.pos_x, joueur1.pos_y - 20, makecol(0, 0, 0), -1);
        textout_ex(page, font, joueur2.pseudo, joueur2.pos_x, joueur2.pos_y - 20, makecol(0, 0, 0), -1);

        //POSER
        poser_objet();
        poser_aliment();
        suivie_pos();
        decoupe();

        //POSSITION
        gestion_pos_objet();

        //AFFICHAGE
        afficher();
        mettre_a_jour_commandes();
        verifier_temps_commandes();
        dessiner_commandes();

        // Affichage sur l'écran
        blit(page, screen, 0, 0, 0, 0, LARGEUR_ECRAN, HAUTEUR_ECRAN);

        rest(10);
    }

    destroy_bitmap(page);
    destroy_bitmap(objet);
    destroy_bitmap(steakcuit);
    destroy_bitmap(Objet2);

    return 0;}
int Niveau3(){
    // Déclaration des variables pour le timer
    clock_t debut_partie, fin_partie;
    int duree_partie = 60; // Durée de la partie en secondes (2 minutes)

    int partie_terminee = 0;

    clear_bitmap(screen);
    // Load images
    chargement_IJ();
    charger_commandes();
    initialisation();
    init_map();
    debut_jeu = clock();
    debut_partie = clock(); // Initialisation du timer de la partie
    ajouter_commande();
    while (!key[KEY_CAPSLOCK]) {
        // Calcul du temps écoulé depuis le début de la partie
        fin_partie = clock();
        double temps_ecoule = (double)(fin_partie - debut_partie) / CLOCKS_PER_SEC;

        // Vérification si le temps écoulé dépasse la durée de la partie
        if (temps_ecoule >= duree_partie) {
            partie_terminee = 1; // Indique que la partie est terminée
            break;
        }

        clear_bitmap(page);
        blit(jeu, page, 0, 0, 0, 120, jeu->w, jeu->h);

        //prendre_lacher();
        //deplacer_objet();
        //fonction_poubelle();

        //MOUVEMENT
        gestion_mouv();

        //ENREGISTRE POSITIONS
        AnciennePosition1();
        AnciennePosition2();

        // Mise à jour des positions des joueurs
        joueur1.pos_x += joueur1.dx;
        joueur1.pos_y += joueur1.dy;
        joueur2.pos_x += joueur2.dx;
        joueur2.pos_y += joueur2.dy;

        //ACTION
        Action();

        //COLISIONS
        check_collision();

        circlefill(page, joueur1.pos_x, joueur1.pos_y, joueur1.rayon, joueur1.couleur);
        circlefill(page, joueur2.pos_x, joueur2.pos_y, joueur2.rayon, joueur2.couleur);
        textout_ex(page, font, joueur1.pseudo, joueur1.pos_x, joueur1.pos_y - 20, makecol(0, 0, 0), -1);
        textout_ex(page, font, joueur2.pseudo, joueur2.pos_x, joueur2.pos_y - 20, makecol(0, 0, 0), -1);

        //POSER
        poser_objet();
        poser_aliment();
        suivie_pos();
        decoupe();

        //POSSITION
        gestion_pos_objet();

        //AFFICHAGE
        afficher();
        mettre_a_jour_commandes();
        verifier_temps_commandes();
        dessiner_commandes();

        // Affichage sur l'écran
        blit(page, screen, 0, 0, 0, 0, LARGEUR_ECRAN, HAUTEUR_ECRAN);

        rest(10);
    }

    if (partie_terminee) {
        menu(); // Appel de la fonction du menu principal pour retourner au menu
    }
    destroy_bitmap(page);
    destroy_bitmap(objet);
    destroy_bitmap(steakcuit);
    destroy_bitmap(Objet2);

    return 0;
}
