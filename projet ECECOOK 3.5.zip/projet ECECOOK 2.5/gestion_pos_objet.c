#include "headers.h"

void gestion_pos_objet(){

    if(joueur1.tenu_assiette !=NULL){
        joueur1.tenu_assiette->pos_x=joueur1.pos_x;
        joueur1.tenu_assiette->pos_y=joueur1.pos_y;
    }
    if(joueur2.tenu_assiette !=NULL){
        joueur2.tenu_assiette->pos_x=joueur2.pos_x;
        joueur2.tenu_assiette->pos_y=joueur2.pos_y;
    }

    if(joueur1.tenu_aliment !=NULL){
        joueur1.tenu_aliment->pos_x=joueur1.pos_x;
        joueur1.tenu_aliment->pos_y=joueur1.pos_y;
    }
    if(joueur2.tenu_aliment !=NULL){
        joueur2.tenu_aliment->pos_x=joueur2.pos_x;
        joueur2.tenu_aliment->pos_y=joueur2.pos_y;
    }
}