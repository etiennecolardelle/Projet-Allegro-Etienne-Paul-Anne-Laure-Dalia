#include "headers.h"

void chargement_IM(){
    page = create_bitmap(LARGEUR_ECRAN, HAUTEUR_ECRAN);
    image_menu[0] = load_bitmap("image/menu/image_menu.bmp", NULL);
    image_menu[1] = load_bitmap("image/menu/jouer.bmp", NULL);
    image_menu[2] = load_bitmap("image/menu/niveau.bmp", NULL);
    image_menu[3] = load_bitmap("image/menu/regle_du_jeu.bmp", NULL);
    image_menu[4] = load_bitmap("image/menu/quitter.bmp", NULL);
}