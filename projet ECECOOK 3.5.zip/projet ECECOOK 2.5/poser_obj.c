#include "headers.h"

/*
void poser_objet() {

    int x = joueur1.pos_x/40, y=joueur1.pos_y/40-3;
    if((joueur1.action==1)&&(joueur1.tenu_assiette!=NULL)&&(map[y-1][x]==1)){
        joueur1.tenu_assiette->pos_x = x*40+20;
        joueur1.tenu_assiette->pos_y = y*40+80+20;
        joueur1.tenu_assiette->tenu=0;
        joueur1.tenu_assiette=NULL;
    }
    if((joueur1.action==1)&&(joueur1.tenu_assiette!=NULL)&&(map[y+1][x]==1)){
        joueur1.tenu_assiette->pos_x = x*40+20;
        joueur1.tenu_assiette->pos_y = y*40+160+20;
        joueur1.tenu_assiette->tenu=0;
        joueur1.tenu_assiette=NULL;
    }
    if((joueur1.action==1)&&(joueur1.tenu_assiette!=NULL)&&(map[y][x-1]==1)){
        joueur1.tenu_assiette->pos_x = x*40-40+20;
        joueur1.tenu_assiette->pos_y = y*40+120+20;
        joueur1.tenu_assiette->tenu=0;
        joueur1.tenu_assiette=NULL;
    }
    if((joueur1.action==1)&&(joueur1.tenu_assiette!=NULL)&&(map[y][x+1]==1)){
        joueur1.tenu_assiette->pos_x = x*40+40+20;
        joueur1.tenu_assiette->pos_y = y*40+120+20;
        joueur1.tenu_assiette->tenu=0;
        joueur1.tenu_assiette=NULL;
    }
    if((joueur1.action==1)&&(joueur1.tenu_assiette==NULL)){
        //DISTRIBUTEUR
        if (map[y - 1][x] == 6) {
            creation_assiette();
        }
        if (map[y + 1][x] == 6) {
            creation_assiette();
        }
        if (map[y][x + 1] == 6) {
            creation_assiette();
        }
        if (map[y][x - 1] == 6) {
            creation_assiette();
        }
    }

    // PRENDRE AJOUTER ASSIETTE
    Assiette *tAssiette = file_plat.debut;
    while (tAssiette != NULL) {
        if ((((joueur1.pos_x / 40)==(tAssiette->pos_x / 40)) && ((joueur1.pos_y / 40)-1)==(tAssiette->pos_y / 40))
        ||(((joueur1.pos_x / 40)==(tAssiette->pos_x / 40)) && ((joueur1.pos_y / 40)+1)==(tAssiette->pos_y / 40))
        ||((((joueur1.pos_x / 40)+1)==(tAssiette->pos_x / 40)) && (joueur1.pos_y / 40)==(tAssiette->pos_y / 40))
        ||(((((joueur1.pos_x / 40)-1))==(tAssiette->pos_x / 40)) && (joueur1.pos_y / 40)==(tAssiette->pos_y / 40))) {
            joueur1.tenu_assiette = tAssiette;
            tAssiette->tenu = 1;
        }
        tAssiette = tAssiette->suivante;
    }
}*/


/*
void poser_objet() {
    int x = joueur1.pos_x / 40, y = joueur1.pos_y / 40 - 3;
    if (joueur1.action == 1 && joueur1.tenu_assiette != NULL) {
        if (map[y - 1][x] == 1) {
            joueur1.tenu_assiette->pos_x = x * 40 + 20;
            joueur1.tenu_assiette->pos_y = (y - 1) * 40 + 20;
        } else if (map[y + 1][x] == 1) {
            joueur1.tenu_assiette->pos_x = x * 40 + 20;
            joueur1.tenu_assiette->pos_y = (y + 1) * 40 + 20;
        } else if (map[y][x - 1] == 1) {
            joueur1.tenu_assiette->pos_x = (x - 1) * 40 + 20;
            joueur1.tenu_assiette->pos_y = y * 40 + 20;
        } else if (map[y][x + 1] == 1) {
            joueur1.tenu_assiette->pos_x = (x + 1) * 40 + 20;
            joueur1.tenu_assiette->pos_y = y * 40 + 20;
        } else {
            // Aucune case adjacente valide
            return;
        }
        joueur1.tenu_assiette->tenu = 0;
        joueur1.tenu_assiette = NULL;
    }

    if (joueur1.action == 1 && joueur1.tenu_assiette == NULL) {
        if (map[y - 1][x] == 6 || map[y + 1][x] == 6 || map[y][x + 1] == 6 || map[y][x - 1] == 6) {
            creation_assiette();
        }
    }

    // Prendre une assiette
    Assiette *tAssiette = file_plat.debut;
    while (tAssiette != NULL) {
        if ((((joueur1.pos_x / 40) == (tAssiette->pos_x / 40)) && ((joueur1.pos_y / 40) - 1) == (tAssiette->pos_y / 40))
            || (((joueur1.pos_x / 40) == (tAssiette->pos_x / 40)) && ((joueur1.pos_y / 40) + 1) == (tAssiette->pos_y / 40))
            || ((((joueur1.pos_x / 40) + 1) == (tAssiette->pos_x / 40)) && (joueur1.pos_y / 40) == (tAssiette->pos_y / 40))
            || ((((joueur1.pos_x / 40) - 1) == (tAssiette->pos_x / 40)) && (joueur1.pos_y / 40) == (tAssiette->pos_y / 40))) {
            joueur1.tenu_assiette = tAssiette;
            tAssiette->tenu = 1;
            break;
        }
        tAssiette = tAssiette->suivante;
    }
}
*/



// Fonction de pose d'objets dans une assiette
void poser_objet() {
    int x = joueur1.pos_x / 40, y = joueur1.pos_y / 40 - 3;

    // Vérifier si le joueur 1 tient une assiette
    if (joueur1.action == 1 && joueur1.tenu_assiette != NULL) {
        // Vérifier si le joueur est sur une case de type 1 pour poser l'assiette
        if (map[y+1][x] == 1 || map[y-1][x] == 1 || map[y][x+1] == 1|| map[y][x-1] == 1) {
            // Calculer les coordonnées de la case centrale pour poser l'assiette
            joueur1.tenu_assiette->pos_x = x * 40 + 20;
            joueur1.tenu_assiette->pos_y = y * 40 + 20;
            joueur1.tenu_assiette->tenu = 0; // Ne plus tenir l'assiette après l'avoir posée
            joueur1.tenu_assiette = NULL; // Réinitialiser l'assiette tenue par le joueur
        }
    }

    // Vérifier si le joueur 1 tient un aliment
    if (joueur1.action == 1 && joueur1.tenu_aliment != NULL) {
        // Vérifier si le joueur est sur une case de type 1 ou 6 pour poser l'aliment
        if (map[y+1][x] == 1 || map[y-1][x] == 1 || map[y][x+1] == 1|| map[y][x-1] == 1|| map[y][x] == 6) {
            // Vérifier si le joueur tient une assiette et placer l'aliment dans l'assiette si c'est le cas
            if (joueur1.tenu_assiette != NULL) {
                joueur1.tenu_aliment->pos_x = joueur1.tenu_assiette->pos_x;
                joueur1.tenu_aliment->pos_y = joueur1.tenu_assiette->pos_y;
                // Ajouter l'aliment à l'assiette
                joueur1.tenu_assiette->ingrediants++;
            } else {
                // Sinon, poser l'aliment sur la case
                joueur1.tenu_aliment->pos_x = x * 40 + 20;
                joueur1.tenu_aliment->pos_y = y * 40 + 20;
            }
            joueur1.tenu_aliment->tenu = 0; // Ne plus tenir l'aliment après l'avoir posé
            joueur1.tenu_aliment = NULL; // Réinitialiser l'aliment tenu par le joueur
        }
    }

    // Prendre une assiette
    Assiette *tAssiette = file_plat.debut;
    while (tAssiette != NULL) {
        if ((((joueur1.pos_x / 40) == (tAssiette->pos_x / 40)) && ((joueur1.pos_y / 40) - 1) == (tAssiette->pos_y / 40))
            || (((joueur1.pos_x / 40) == (tAssiette->pos_x / 40)) && ((joueur1.pos_y / 40) + 1) == (tAssiette->pos_y / 40))
            || ((((joueur1.pos_x / 40) + 1) == (tAssiette->pos_x / 40)) && (joueur1.pos_y / 40) == (tAssiette->pos_y / 40))
            || ((((joueur1.pos_x / 40) - 1) == (tAssiette->pos_x / 40)) && (joueur1.pos_y / 40) == (tAssiette->pos_y / 40))) {
            joueur1.tenu_assiette = tAssiette;
            tAssiette->tenu = 1;
            break;
        }
        tAssiette = tAssiette->suivante;
    }

    if ((joueur1.action == 1) && (joueur1.tenu_assiette != NULL)) {
        if (map[y-1][x] == 5) {
            // Si le joueur est sur la case de la poubelle, retirer l'assiette
            free(joueur1.tenu_assiette); // Libérer la mémoire allouée pour l'assiette
            joueur1.tenu_assiette = NULL; // Réinitialiser l'assiette tenue par le joueur
        }
        if (map[y+1][x] == 5) {
            // Si le joueur est sur la case de la poubelle, retirer l'assiette
            free(joueur1.tenu_assiette); // Libérer la mémoire allouée pour l'assiette
            joueur1.tenu_assiette = NULL; // Réinitialiser l'assiette tenue par le joueur
        }
        if (map[y][x-1] == 5) {
            // Si le joueur est sur la case de la poubelle, retirer l'assiette
            free(joueur1.tenu_assiette); // Libérer la mémoire allouée pour l'assiette
            joueur1.tenu_assiette = NULL; // Réinitialiser l'assiette tenue par le joueur
        }
        if (map[y][x+1] == 5) {
            // Si le joueur est sur la case de la poubelle, retirer l'assiette
            free(joueur1.tenu_assiette); // Libérer la mémoire allouée pour l'assiette
            joueur1.tenu_assiette = NULL; // Réinitialiser l'assiette tenue par le joueur
        }
    }

    else if ((joueur1.action == 1) && (joueur1.tenu_assiette != NULL)) {

        if (map[y-1][x] == 5) {
            // Si le joueur est sur la case de la poubelle, retirer l'aliment
            free(joueur1.tenu_aliment); // Libérer la mémoire allouée pour l'aliment
            joueur1.tenu_aliment = NULL; // Réinitialiser l'aliment tenu par le joueur
        }
        if (map[y+1][x] == 5) {
            // Si le joueur est sur la case de la poubelle, retirer l'aliment
            free(joueur1.tenu_aliment); // Libérer la mémoire allouée pour l'aliment
            joueur1.tenu_aliment = NULL; // Réinitialiser l'aliment tenu par le joueur
        }
        if (map[y][x-1] == 5) {
            // Si le joueur est sur la case de la poubelle, retirer l'aliment
            free(joueur1.tenu_aliment); // Libérer la mémoire allouée pour l'aliment
            joueur1.tenu_aliment = NULL; // Réinitialiser l'aliment tenu par le joueur
        }if (map[y][x+1] == 5) {
            // Si le joueur est sur la case de la poubelle, retirer l'aliment
            free(joueur1.tenu_aliment); // Libérer la mémoire allouée pour l'aliment
            joueur1.tenu_aliment = NULL; // Réinitialiser l'aliment tenu par le joueur
        }

    }
}
